# Don't create a new migration file here

Please go to ./db/knex_migrations/README.md
